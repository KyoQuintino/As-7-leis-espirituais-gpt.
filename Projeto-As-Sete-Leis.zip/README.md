# Site — As Sete Leis Espirituais para o Sucesso

## Conteúdo
- `index.html`: página de vendas responsiva.
- `styles.css`: identidade visual preto e dourado.
- `script.js`: menu mobile e configuração do CTA.
- `assets/imagem-promocional-hotmart.png`: imagem promocional gerada.
- `assets/mockup-ebook.jpg`: visual do e-book para a página.

## Antes de publicar
1. Abra `script.js` e substitua `const CHECKOUT_URL` pela URL pública do checkout da sua oferta Hotmart.
2. Revise nome, preço, condições de entrega, política de reembolso e garantia de acordo com sua oferta real.
3. Substitua o espaço de depoimentos por avaliações autênticas, com autorização dos clientes.
4. Confirme que possui os direitos necessários para comercializar o material e usar nomes/imagens de terceiros.

## Publicação
Envie os arquivos para um repositório GitHub e importe o repositório na Vercel. A pasta raiz do projeto contém o `index.html`; não é necessário build.
